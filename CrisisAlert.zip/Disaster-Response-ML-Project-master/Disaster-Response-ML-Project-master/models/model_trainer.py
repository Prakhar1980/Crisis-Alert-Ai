import sys
import nltk
import numpy as np
nltk.download(['punkt', 'wordnet', 'stopwords'])
from nltk.tokenize import word_tokenize, RegexpTokenizer
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords
import pandas as pd
from sqlalchemy import create_engine
import re
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.multioutput import MultiOutputClassifier
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from sklearn.metrics import classification_report
from xgboost import XGBClassifier
import pickle

def load_data(database_filepath):
    """Load the filepath and return the data"""
    name = 'sqlite:///' + database_filepath
    engine = create_engine(name)
    df = pd.read_sql_table('CrisisData', con=engine)  
    print(df.head())
    X = df['message']
    y = df[df.columns[4:]]
    category_names = y.columns
    return X, y, category_names

def tokenize(text):
    """Tokenize and transform input text. Returns cleaned text"""
    url_regex = r"http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+"
    detected_urls = re.findall(url_regex, text)
    for url in detected_urls:
        text = text.replace(url, "urlplaceholder")
    
    tokenizer = RegexpTokenizer(r'\w+')
    tokens = tokenizer.tokenize(text)
    
    lemmatizer = WordNetLemmatizer()
    stop_words = set(stopwords.words("english"))  
    
    clean_tokens = [lemmatizer.lemmatize(tok).lower().strip() for tok in tokens if tok.lower() not in stop_words]
    return clean_tokens

def build_model():
    """Return Grid Search model with pipeline and Classifier"""
    moc = MultiOutputClassifier(XGBClassifier(n_estimators=100, learning_rate=0.1)) 

    pipeline = Pipeline([
        ('vect', CountVectorizer(tokenizer=tokenize)),
        ('tfidf', TfidfTransformer()),
        ('clf', moc)
    ])

    parameters = {'clf__estimator__learning_rate': [0.05, 0.1, 0.2],
                  'clf__estimator__n_estimators': [50, 100, 150]}  
    
    cv = GridSearchCV(pipeline, parameters)
    return cv

def evaluate_model(model, X_test, y_test, category_names):
    """Evaluate model and save results to CSV"""
    y_pred = model.predict(X_test)
    
    results = pd.DataFrame(columns=['Category', 'Precision', 'Recall', 'F1-Score'])
    
    for i, col in enumerate(category_names):
        report = classification_report(y_test.iloc[:, i], y_pred[:, i], output_dict=True)
        results = results.append({'Category': col, 
                                  'Precision': report['weighted avg']['precision'], 
                                  'Recall': report['weighted avg']['recall'], 
                                  'F1-Score': report['weighted avg']['f1-score']}, 
                                 ignore_index=True)
    
    results.to_csv("model_results.csv", index=False)
    print("Model evaluation saved to 'model_results.csv'")

def save_model(model, model_filepath):
    """Save model as pickle file"""
    pickle.dump(model, open(model_filepath, 'wb'))

def main():
    """Load the data, run the model and save model"""
    if len(sys.argv) == 3:
        database_filepath, model_filepath = sys.argv[1:]
        print('Loading data...\n    DATABASE: {}'.format(database_filepath))
        X, Y, category_names = load_data(database_filepath)
        X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.25)
        
        print('Building model...')
        model = build_model()
        
        print('Training model...')
        model.fit(X_train, Y_train)
        
        print('Evaluating model...')
        evaluate_model(model, X_test, Y_test, category_names)

        print('Saving model...\n    MODEL: {}'.format(model_filepath))
        save_model(model, model_filepath)

        print('Trained model saved!')

    else:
        print('Please provide the filepath of the disaster messages database '\
              'as the first argument and the filepath of the pickle file to '\
              'save the model to as the second argument. \n\nExample: python '\
              'train_model.py ../data/DisasterResponse.db classifier.pkl')

if __name__ == '__main__':
    main()
