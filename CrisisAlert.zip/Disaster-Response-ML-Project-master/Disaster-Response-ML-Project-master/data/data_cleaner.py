import sys
import pandas as pd
from sqlalchemy import create_engine

def load_dataset(messages_path, categories_path):
    """Load messages and categories datasets and merge them.
    
    INPUT:
    messages_path -- str, path to messages CSV file
    categories_path -- str, path to categories CSV file
    
    OUTPUT:
    df -- pandas DataFrame containing merged datasets
    """
    messages = pd.read_csv(messages_path)
    categories = pd.read_csv(categories_path)
    df = messages.merge(categories, on='id')
    return df

def clean_dataset(df):
    """Cleans the dataset and transforms category columns into separate binary values.
    
    INPUT:
    df -- pandas DataFrame containing raw merged data
    
    OUTPUT:
    df -- cleaned pandas DataFrame
    """
    categories = df['categories'].str.split(';', expand=True)
    category_names = [col.split('-')[0] for col in categories.loc[0]]
    
    print('Extracted Category Names:', category_names)
    
    categories.columns = category_names
    for column in categories:
        categories[column] = categories[column].str[-1].astype(int)
    
    df.drop('categories', axis=1, inplace=True)
    df = pd.concat([df, categories], axis=1)
    df.drop_duplicates(inplace=True)
    
    # Removing any inconsistent data where 'related' column has value other than 0 or 1
    df = df[df['related'] != 2]
    
    print(f'Removed duplicate rows. Remaining Duplicates: {df.duplicated().sum()}')
    
    return df

def save_to_database(df, database_name):
    """Saves the cleaned dataset into an SQLite database.
    
    INPUT:
    df -- pandas DataFrame containing cleaned data
    database_name -- str, name of the database file
    """
    db_path = 'sqlite:///' + database_name
    engine = create_engine(db_path)
    
    try:
        df.to_sql('CrisisData', engine, index=False, if_exists='replace')
        print(f'Data successfully saved to database: {database_name}')
    except Exception as e:
        print(f'Error saving data to database: {e}')

def main():
    """Main function to execute ETL steps: Load, Clean, and Save."""
    if len(sys.argv) == 4:
        messages_path, categories_path, database_path = sys.argv[1:]

        print(f'Loading datasets...\n  MESSAGES: {messages_path}\n  CATEGORIES: {categories_path}')
        df = load_dataset(messages_path, categories_path)

        print('Cleaning the dataset...')
        df = clean_dataset(df)

        print(f'Saving cleaned data to database: {database_path}')
        save_to_database(df, database_path)

        print('Processing complete! Data stored successfully.')

    else:
        print('Usage: python data_processor.py <messages.csv> <categories.csv> <database.db>\n'
              'Example: python data_processor.py crisis_messages.csv crisis_categories.csv CrisisAlert.db')

if __name__ == '__main__':
    main()
