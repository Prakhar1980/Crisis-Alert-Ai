import json
import pickle
import plotly
import pandas as pd
import spacy

from flask import Flask, render_template, request
from plotly.graph_objs import Pie, Bar
from sqlalchemy import create_engine

# Load SpaCy model
nlp = spacy.load("en_core_web_sm")

app = Flask(__name__)

def tokenize(text):
    """Tokenizes and lemmatizes input text using SpaCy."""
    doc = nlp(text)
    clean_tokens = [token.lemma_.lower().strip() for token in doc if not token.is_stop]
    return clean_tokens

# Load data
db_path = 'sqlite:///../data/CrisisAid.db'
engine = create_engine(db_path)
df = pd.read_sql_table('CrisisData', engine)

# Load model
with open("../models/classifier.pkl", "rb") as f:
    model = pickle.load(f)

@app.route('/')
@app.route('/index')
def index():
    """Renders the index page with visualizations."""
    genre_counts = df.groupby('genre').count()['message']
    genre_names = list(genre_counts.index)
    
    cats = df[df.columns[5:]]
    cats_counts = cats.mean() * cats.shape[0]
    cats_names = list(cats_counts.index)
    nlarge_counts = cats_counts.nlargest(5)
    nlarge_names = list(nlarge_counts.index)
    
    graphs = [
        {
            'data': [
                Pie(
                    labels=genre_names,
                    values=genre_counts
                )
            ],
            'layout': {
                'title': 'Distribution of Message Genres'
            }
        },
        {
            'data': [
                Bar(
                    x=nlarge_names,
                    y=nlarge_counts
                )
            ],
            'layout': {
                'title': 'Top Message Categories',
                'yaxis': {'title': "Count"},
                'xaxis': {'title': "Category"}
            }
        }
    ]
    
    ids = ["graph-{}".format(i) for i, _ in enumerate(graphs)]
    graphJSON = json.dumps(graphs, cls=plotly.utils.PlotlyJSONEncoder)
    
    return render_template('master.html', ids=ids, graphJSON=graphJSON)

@app.route('/go')
def go():
    """Handles user query and displays model results."""
    query = request.args.get('query', '')
    classification_labels = model.predict([query])[0]
    classification_results = dict(zip(df.columns[4:], classification_labels))
    
    return render_template('go.html', query=query, classification_result=classification_results)

def main():
    """Runs the Flask app."""
    app.run(host='127.0.0.1', port=5000, debug=False)

if __name__ == '__main__':
    main()